<?php
error_reporting (E_ERROR ); 
    function isXML($data)
    {
        libxml_use_internal_errors(true);
        $doc = new DOMDocument('1.0', 'utf-8');
        $doc->loadXML($data);

        $errors = libxml_get_errors();
        if (empty($errors))
        {
            return true;
        }
        return false;     
    }

    function replace_all_to_htmltag($chaine)
    {

        //  les accents
        $chaine = trim($chaine);
        $chaine = utf8_encode($chaine);
        $chaine = strtr($chaine, array(
            'Š' => 'S', 'š' => 's', 'Ð' => 'Dj', 'Ž' => 'Z', 'ž' => 'z', 'À' => 'A', 'Á' => 'A', 'Â' => 'A', 'Ã' => 'A', 'Ä' => 'A',
            'Å' => 'A', 'Æ' => 'A', 'Ç' => 'C', 'È' => 'E', 'É' => 'E', 'Ê' => 'E', 'Ë' => 'E', 'Ì' => 'I', 'Í' => 'I', 'Î' => 'I',
            'Ï' => 'I', 'Ñ' => 'N', 'Ò' => 'O', 'Ó' => 'O', 'Ô' => 'O', 'Õ' => 'O', 'Ö' => 'O', 'Ø' => 'O', 'Ù' => 'U', 'Ú' => 'U',
            'Û' => 'U', 'Ü' => 'U', 'Ý' => 'Y', 'Þ' => 'B', 'ß' => 'Ss', 'à' => 'a', 'á' => 'a', 'â' => 'a', 'ã' => 'a', 'ä' => 'a',
            'å' => 'a', 'æ' => 'a', 'ç' => 'c', 'è' => 'e', 'é' => 'e', 'ê' => 'e', 'ë' => 'e', 'ì' => 'i', 'í' => 'i', 'î' => 'i',
            'ï' => 'i', 'ð' => 'o', 'ñ' => 'n', 'ò' => 'o', 'ó' => 'o', 'ô' => 'o', 'õ' => 'o', 'ö' => 'o', 'ø' => 'o', 'ù' => 'u',
            'ú' => 'u', 'û' => 'u', 'ý' => 'y', 'ý' => 'y', 'þ' => 'b', 'ÿ' => 'y', 'ƒ' => 'f',
            /* custom here */ '(' => '-', ')' => '-', '>' => '-', '<' => '-', '[' => '-', ']' => '-', ' ' => '-', "'" => '-'
                ));
        //  les caracètres spéciaux (aures que lettres et chiffres en fait)
        $chaine = preg_replace('/([^.a-z0-9]+)/i', '-', $chaine);

        if (preg_match('/[a-z]|_/i', $chaine[0]) == 0) //Si ça commence par un chiffre
            $chaine = "_" . $chaine;

        return $chaine;
    }

    header("content-type: text/xml;charset=charset=ISO-8859-1");
    mysql_connect('192.168.50.103', 'acppe', 'BDZ7G62GE328');
    //mysql_connect('localhost', 'root', 'root');
    mysql_select_db('acppe_dev');

    file_put_contents("/var/log/acppeAPI.log", "\n\nLog API VISIT : " . date(DATE_RFC822), FILE_APPEND | LOCK_EX);
    file_put_contents("/var/log/acppeAPI.log", "\n REQUEST  : " . var_export($_REQUEST, true), FILE_APPEND | LOCK_EX);
    $echo = "";
    $echo .= '<?xml version="1.0" encoding="utf-8" ?><root>';

    $from = substr(urldecode($_GET["from"]), 0, 10);
    $to = urldecode($_GET["to"]);
    $event = "";
    if (isset($_GET["event"]) && $_GET["event"] != "Tous")
        $event = "AND  visit.`EVENT` = '" . urldecode($_GET["event"]) . "'";

    $classesArray = array();
    $classes = mysql_query("SELECT * FROM visit_class ");
    while (($class = mysql_fetch_array($classes)))
    {
        $classesArray[$class["ID_VISIT_CLASS"]] = $class["NAME"];
    }

    if ($_GET["by"] == "Toutvoir")
    {

        //Total sur la periode
        $totalrequest = "select 'Total : ' as Date ";
        $totalrequest .= ", CONCAT(SUM(visit.`PRICE`),'') as Gain ";
        foreach ($classesArray as $key => $class)
        {
            $totalrequest .= ",SUM((select visit_count.COUNT from visit_count where visit_count.ID_VISIT =  visit.ID_VISIT AND visit_count.ID_VISIT_CLASS = " . $key . " )) as '" . replace_all_to_htmltag(($class)) . "' ";
        }
        $totalrequest .= " from visit WHERE visit.`DATE` >= '$from' AND visit.`DATE` < '$to' $event GROUP BY 1 order by visit.`DATE` ; ";
        $rows = mysql_query($totalrequest);
        $row = mysql_fetch_array($rows);
        $echo .= "<row>";
        if (mysql_num_rows($rows) == 0)
        {
            file_put_contents("/var/log/acppeAPI.log", "aucun résultat", FILE_APPEND | LOCK_EX);
            exit('<?xml version="1.0" encoding="utf-8" ?><root><row><_>Aucun résultat sur cette période.                                                                               </_></row></root>');
        } foreach ($row as $key => $value)
        {
            if (!is_numeric($key))
                $echo .= "<$key>$value</$key>";
        }
        $echo .= "</row><row></row>";

        $request = "select visit.`DATE`as Date ";
        $request .= ", visit.`PRICE` as Gain ";
        $request .= ", visit.`CUSTOMER` as Client ";
        $request .= ", visit.`EVENT` as Evenement ";
        $request .= ", visit.`IS_GROUP` as Groupe ";
        $request .= ", visit.`COMMENT` as Commentaire ";
        foreach ($classesArray as $key => $class)
        {

            $request .= ",(select visit_count.COUNT from visit_count where visit_count.ID_VISIT =  visit.ID_VISIT AND visit_count.ID_VISIT_CLASS = " . $key . " ) as '" . replace_all_to_htmltag(($class)) . "' ";
        }
        $request .= " from visit WHERE visit.`DATE` >= '$from' AND visit.`DATE` < '$to' $event order by visit.`DATE` ; ";

        $rows = mysql_query($request);
        while (($row = mysql_fetch_array($rows)))
        {
            $echo .= "<row>";
            foreach ($row as $key => $value)
            {
                if (!is_numeric($key))
                    $echo .= "<$key>$value</$key>";
            }
            $echo .= "</row>";
        }
    }
    else if ($_GET["by"] == "Jour")
    {
        //Total sur la periode
        $totalrequest = "select 'Total : ' as Jour ";
        $totalrequest .= ", CONCAT(SUM(visit.`PRICE`),'') as Gain ";
        foreach ($classesArray as $key => $class)
        {
            $totalrequest .= ",SUM((select visit_count.COUNT from visit_count where visit_count.ID_VISIT =  visit.ID_VISIT AND visit_count.ID_VISIT_CLASS = " . $key . " )) as '" . replace_all_to_htmltag(($class)) . "' ";
        }
        $totalrequest .= " from visit WHERE visit.`DATE` >= '$from' AND visit.`DATE` < '$to' $event GROUP BY 1 order by visit.`DATE` ; ";
        $rows = mysql_query($totalrequest);
        $row = mysql_fetch_array($rows);
        $echo .= "<row>";
        if (mysql_num_rows($rows) == 0)
        {
            file_put_contents("/var/log/acppeAPI.log", "aucun résultat", FILE_APPEND | LOCK_EX);
            exit('<?xml version="1.0" encoding="utf-8" ?><root><row><_>Aucun résultat sur cette période.                                                                               </_></row></root>');
        } foreach ($row as $key => $value)
        {
            if (!is_numeric($key))
                $echo .= "<$key>$value</$key>";
        }
        $echo .= "</row><row></row>";

        $request = "select visit.`DATE`as Jour ";
        $request .= ", SUM(visit.`PRICE`) as Gain ";
        foreach ($classesArray as $key => $class)
        {
            $request .= ",SUM((select visit_count.COUNT from visit_count where visit_count.ID_VISIT =  visit.ID_VISIT AND visit_count.ID_VISIT_CLASS = " . $key . " )) as '" . replace_all_to_htmltag(($class)) . "' ";
        }
        $request .= " from visit WHERE visit.`DATE` >= '$from' AND visit.`DATE` < '$to' $event GROUP BY DAY(visit.`DATE`) , MONTH(visit.`DATE`) , YEAR(visit.`DATE`) order by visit.`DATE` ; ";

        $rows = mysql_query($request);

        while (($row = mysql_fetch_array($rows)))
        {
            $echo .= "<row>";
            foreach ($row as $key => $value)
            {
                if (!is_numeric($key))
                    $echo .= "<$key>$value</$key>";
            }
            $echo .= "</row>";
        }
    }
    else if ($_GET["by"] == "Mois")
    {
        //Total sur la periode
        $totalrequest = "select 'Total : ' as 'Annee-Mois' ";
        $totalrequest .= ", CONCAT(SUM(visit.`PRICE`),'') as Gain ";
        foreach ($classesArray as $key => $class)
        {
            $totalrequest .= ",SUM((select visit_count.COUNT from visit_count where visit_count.ID_VISIT =  visit.ID_VISIT AND visit_count.ID_VISIT_CLASS = " . $key . " )) as '" . replace_all_to_htmltag(($class)) . "'";
        }
        $totalrequest .= " from visit WHERE visit.`DATE` >= '$from' AND visit.`DATE` < '$to' $event GROUP BY 1 order by visit.`DATE` ; ";
        $rows = mysql_query($totalrequest);
        $row = mysql_fetch_array($rows);
        $echo .= "<row>";
        if (mysql_num_rows($rows) == 0)
        {
            file_put_contents("/var/log/acppeAPI.log", "aucun résultat", FILE_APPEND | LOCK_EX);
            exit('<?xml version="1.0" encoding="utf-8" ?><root><row><_>Aucun résultat sur cette période.                                                                               </_></row></root>');
        } foreach ($row as $key => $value)
        {
            if (!is_numeric($key))
                $echo .= "<$key>$value</$key>";
        }
        $echo .= "</row><row></row>";

        $request = "select CONCAT(YEAR(visit.`DATE`),'-',MONTH(visit.`DATE`)) as 'Annee-Mois' ";
        $request .= ", SUM(visit.`PRICE`) as Gain ";
        foreach ($classesArray as $key => $class)
        {
            $request .= ",SUM((select visit_count.COUNT from visit_count where visit_count.ID_VISIT =  visit.ID_VISIT AND visit_count.ID_VISIT_CLASS = " . $key . " )) as '" . replace_all_to_htmltag(($class)) . "' ";
        }
        $request .= " from visit WHERE visit.`DATE` >= '$from' AND visit.`DATE` < '$to' $event GROUP BY MONTH(visit.`DATE`) , YEAR(visit.`DATE`) order by visit.`DATE` ; ";

        $rows = mysql_query($request);

        while (($row = mysql_fetch_array($rows)))
        {
            $echo .= "<row>";
            foreach ($row as $key => $value)
            {
                if (!is_numeric($key))
                    $echo .= "<$key>$value</$key>";
            }
            $echo .= "</row>";
        }
    }
    else if ($_GET["by"] == "Anne")
    {
        //Total sur la periode
        $totalrequest = "select 'Total : ' as 'Annees'";
        $totalrequest .= ", CONCAT(SUM(visit.`PRICE`),'') as Gain ";
        foreach ($classesArray as $key => $class)
        {
            $totalrequest .= ",SUM((select visit_count.COUNT from visit_count where visit_count.ID_VISIT =  visit.ID_VISIT AND visit_count.ID_VISIT_CLASS = " . $key . " )) as '" . replace_all_to_htmltag(($class)) . "' ";
        }
        $totalrequest .= " from visit WHERE visit.`DATE` >= '$from' AND visit.`DATE` < '$to' $event GROUP BY 1 order by visit.`DATE` ; ";
        $rows = mysql_query($totalrequest);
        $row = mysql_fetch_array($rows);
        $echo .= "<row>";
        if (mysql_num_rows($rows) == 0)
        {
            file_put_contents("/var/log/acppeAPI.log", "aucun résultat", FILE_APPEND | LOCK_EX);
            exit('<?xml version="1.0" encoding="utf-8" ?><root><row><_>Aucun résultat sur cette période.                                                                               </_></row></root>');
        }
        foreach ($row as $key => $value)
        {
            if (!is_numeric($key))
                $echo .= "<$key>$value</$key>";
        }
        $echo .= "</row><row></row>";

        $request = "select YEAR(visit.`DATE`) as 'Annees' ";
        $request .= ", SUM(visit.`PRICE`) as Gain ";
        foreach ($classesArray as $key => $class)
        {
            $request .= ",SUM((select visit_count.COUNT from visit_count where visit_count.ID_VISIT =  visit.ID_VISIT AND visit_count.ID_VISIT_CLASS = " . $key . " )) as '" . replace_all_to_htmltag(($class)) . "' ";
        }
        $request .= " from visit WHERE visit.`DATE` >= '$from' AND visit.`DATE` < '$to' $event GROUP BY YEAR(visit.`DATE`) order by visit.`DATE` ; ";

        $rows = mysql_query($request);

        while (($row = mysql_fetch_array($rows)))
        {
            $echo .= "<row>";
            foreach ($row as $key => $value)
            {
                if (!is_numeric($key))
                    $echo .= "<$key>$value</$key>";
            }
            $echo .= "</row>";
        }
    }
    else
        $echo .= "Mauvais param by";

    $echo .= "</root>";

	file_put_contents("/var/log/acppeAPI.log", "\nSQL : ".$request, FILE_APPEND | LOCK_EX);
    file_put_contents("/var/log/acppeAPI.log", "\nXML return : ".$echo, FILE_APPEND | LOCK_EX);

    if (!isXML(utf8_encode($echo)))
    {
        $headers = 'From: Gesmap monitor <noreply@wink-dev.com>' . "\n";
        $headers .='Content-Type: text/html; charset="iso-8859-1"' . "\n";
        $headers .='Content-Transfer-Encoding: 8bit';
        mail("bastien@wink-dev.com", "ACPPE API ERROR ID " . time(), "Fix time !! <br /><br /><br />This request : <br />" . var_export($_REQUEST, true) . "<br /><br />Return this XML, it have been detected as invalid : <br />" . htmlentities($echo) . " <br /><br /> Last SQL requets is <br/> $request", $headers);
        exit('<?xml version="1.0" encoding="utf-8" ?><root><row><_>Erreur détecté, le mail n°' . time() . ' d\'avertissement à été envoyé au développeur.</_></row></root>');
    }

    echo utf8_encode($echo);
?>
